<?php 
$string='sql("UPDATE membership_users SET otp=\'$otp\',otp_status=\'0\',otp_expiry=\'$stamp\' WHERE memberID=\'$username\'",$eo);';

echo $string;



 ?>