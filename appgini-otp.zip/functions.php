<?php  
require_once 'lib/vendor/autoload.php';

$plugin_status=sqlValue("SELECT status FROM appgini_otp WHERE id='1'");

function obfuscate_email($email)
{
	$em   = explode("@",$email);
	$name = implode('@', array_slice($em, 0, count($em)-1));
	$len  = floor(strlen($name)/2);

	return substr($name,0, $len) . str_repeat('*', $len) . "@" . end($em);   
}

function sendEmail($recipient,$title,$msg){
	include 'config.php';
	$transport = (new Swift_SmtpTransport($adminConfig['smtp_server'], $adminConfig['smtp_port'], $adminConfig['smtp_encryption']))
	->setUsername($adminConfig['smtp_user'])
	->setPassword($adminConfig['smtp_pass']);

    // Create the Mailer using your created Transport
	$mailer = new Swift_Mailer($transport);
		// Create a message
		$message = (new Swift_Message($title))
		->setFrom([$adminConfig['smtp_user'] => $adminConfig['senderName']])
		->setTo($recipient)
		->addPart($msg, "text/html")
		->setBody('Hello! User');
        // Send the message
		$result = $mailer->send($message);

		if(!$result){
			return $result;
		} else {
			return TRUE;
		}

}

function getTargetLine($file){
	$content = file($file);
	foreach ($content as $line_num => $line) {
		$lineContent=$line;
		if (preg_match("/function login_ok/i", $lineContent)){
			$targetline=$line_num;
			return  $targetline;
		}
	}
}
