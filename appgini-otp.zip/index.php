<?php 
/**
 * include important things first
 */
define("PREPEND_PATH", "../../");
$hooks_dir = dirname(__FILE__);
include("../../defaultLang.php");
include("../../language.php");
include("../../lib.php");
include_once("../../header.php");
copy("../../config.php","config.php");
include 'config.php';
include 'functions.php';
$info=getMemberInfo();
$group=$info['group'];
$username=$info['username'];
if ($group!=="Admins") {
    # code...
	echo error_message("Access denied please login as admin to continue.");exit;
}
?>
<!--CODE INSERTED FOR SWEET ALERT-->
<script type="text/javascript" src="https://www.jquery-az.com/javascript/alert/dist/sweetalert-dev.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.jquery-az.com/javascript/alert/dist/sweetalert.css"><!--CODE INSERTED FOR SWEET ALERT-->
<div class="container">
	<div class="jumbotron text-center">
		<h1><img src="otp.png"> Appgini OTP Plugin</h1>
		<p>This plugin will enable you activate two step verification using email OTP in your Appgini application. Once activated, all users who attempt to login to your application will be sent an OTP to their registered email for verification.This happens all the time a user logs in. To use this plugin you must use SMTP as your mail sending method.</p>
	</div>
	<!-- Display the SMTP Parameters for admin -->
	<div class="well well-lg">
		<h4>SMTP Enabled? <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? "YES" : "NO" ; ?></span></h4>
		<h4>SMTP Server: <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? $adminConfig['smtp_server'] : "None" ; ?></span></h4>
		<h4>SMTP Port: <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? $adminConfig['smtp_port'] : "None" ; ?></span></h4>
		<h4>SMTP Encryption: <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? $adminConfig['smtp_encryption'] : "None" ; ?></span></h4>
		<h4>SMTP User: <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? $adminConfig['smtp_user'] : "None" ; ?></span></h4>
		<h4>Sender Name: <span class="label label-default"><?php echo $retVal = ($adminConfig['mail_function']=="smtp") ? $adminConfig['senderName'] : "None" ; ?></span></h4>
	</div>
	<!-- Install,Activate or Deactivate plugin -->
	<div class="well well-sm">
		<?php 
		$file_pointer='../../verify_account.php';
		if (file_exists($file_pointer)) {
			?>
			<?php if($plugin_status==1){?>
				<div>
					<form method="POST" action="">
						<button type="submit" name="deactivate" class="btn btn-danger btn-lg"><b>Deactivate OTP Plugin</b></button>
					</form>
				</div>
			<?php } else{ ?>
				<div>
					<form method="POST" action="">
						<button type="submit" name="activate" class="btn btn-success btn-lg"><b>Activate OTP Plugin</b></button>
					</form>
				</div>
			<?php } ?>
		<?php } else{?>
			<div>
				<form method="POST" action="">
					<button type="submit" name="install" class="btn btn-success btn-lg"><b>Install OTP Plugin</b></button>
				</form>
			</div>
		<?php } ?>
	</div>
</div>

<?php 
if (isset($_POST['install'])) {
		// code...check if smtp is enabled
	if ($adminConfig['mail_function']!=="smtp") {
			// code...
		echo '<script type="text/javascript">swal("Oops!", "Please enable SMTP(From Admin Area) first to use this plugin", "error");</script>';exit;
	}
	else{
		sql("CREATE TABLE appgini_otp (id INT(1)  UNSIGNED AUTO_INCREMENT PRIMARY KEY, status INT(1) NOT NULL)",$eo);
		sql("INSERT INTO appgini_otp SET status='1'",$eo);
		sql("ALTER TABLE membership_users ADD otp INT(6) NOT NULL  AFTER flags, ADD otp_status INT(1) NOT NULL  AFTER otp, ADD otp_expiry DATETIME NOT NULL  AFTER otp_status",$eo);
		copy("verify_account.php", "../../verify_account.php");
		sql("UPDATE membership_users SET otp_status='1' WHERE memberID='$username'",$eo);

		$file = "../../hooks/__global.php";
		$targetline=getTargetLine($file);
			$content = file($file); //Read the file into an array. Line number => line content
			foreach($content as $lineNumber => &$lineContent) { //Loop through the array (the "lines")
			    if($lineNumber == $targetline) { //Remember we start at line 0.
			    	$lineContent .= '//Code Start: Appgini OTP Plugin
			    	if(sqlValue("SELECT status FROM appgini_otp")==1){
			    		require_once ("plugins/appgini-otp/functions.php");
			    		$username=$memberInfo["username"];
			    		$otp=mt_rand(123456,789101);
			    		$minutes_to_add = 10;
			    		$time = new DateTime(date("Y-m-d H:i:s"));
			    		$time->add(new DateInterval("PT" . $minutes_to_add . "M"));
			    		$stamp = $time->format("Y-m-d H:i:s");
			    		$email=$memberInfo["email"];
			    		sql("UPDATE membership_users SET otp=\'$otp\',otp_status=\'0\',otp_expiry=\'$stamp\' WHERE memberID=\'$username\'",$eo);
			    		sendEmail($email,"Please Verify It Is You","Dear $username, If you are attempting to sign-in, please use the following code to confirm your identity: <b>$otp</b> <br> This code expires in 10 minutes. If you are not the one attempting to login to your account please ignore this.");
					}//Code End: Appgini OTP' . PHP_EOL; //Modify the line. (We're adding another line by using PHP_EOL)
				}

			}
			$allContent = implode("", $content); //Put the array back into one string
			file_put_contents($file, $allContent); //Overwrite the file with the new content

			file_put_contents('../../hooks/header-extras.php','<?php 
				//Code Start: Appgini OTP Plugin		
				$username=getLoggedMemberID();
				if ($username!=="guest") {
  						// code...
					$otp_status=sqlValue("SELECT otp_status FROM membership_users WHERE memberID=\'$username\'");
					if ($otp_status==0) {
 						 // code...
						header("Location: verify_account.php");
					}
					}//Code End: Appgini OTP
					?>'."\n", FILE_APPEND);
			echo '<script type="text/javascript">swal("Congrats!", "AppGini OTP Plugin Successfully Installed.", "success");</script>';
			header("Refresh:2;");

		}

	}

	if (isset($_POST['deactivate'])) {
			// code...deactivate plugin in the db
		sql("UPDATE appgini_otp SET status=0 WHERE id=1",$eo);
		sql("UPDATE membership_users SET otp_status=1",$eo);
		echo '<script type="text/javascript">swal("Congrats!", "AppGini OTP Plugin Successfully Deactivated.", "success");</script>';
		header("Refresh:2;");

	}

	if (isset($_POST['activate'])) {
			// code...activate plugin in the db
		sql("UPDATE appgini_otp SET status=1 WHERE id=1",$eo);
		echo '<script type="text/javascript">swal("Congrats!", "AppGini OTP Plugin Successfully Activated.", "success");</script>';
		header("Refresh:2; url=../../index.php");

	}


	?>
